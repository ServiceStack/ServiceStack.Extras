﻿///////////////////////////////////////////////////////////////////////////////
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
///////////////////////////////////////////////////////////////////////////////
using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Unity;
using Common;
using Module1.Views;

namespace Module1.Controllers
{
    /// <summary>
    /// Controllers are typically used to programmatically coordinate
    /// the display of views in regions (i.e. View Injection) and to
    /// implement navigation.
    /// This example uses a loosely coupled event fired from the
    /// MasterViewModel to display one of two views in the Shell's main region.
    /// </summary>
    public class MainRegionController
    {
        private readonly IUnityContainer _container;
        private readonly IRegionManager _regionManager;
        private readonly IEventAggregator _eventAggregator;

        public MainRegionController(IUnityContainer container,
                                     IRegionManager regionManager,
                                     IEventAggregator eventAggregator)
        {
            _container = container;
            _regionManager = regionManager;
            _eventAggregator = eventAggregator;

            // Subscribe to the SwitchView event.
            _eventAggregator.GetEvent<SwitchViewEvent>().Subscribe(SwitchViewEventHandler, true);

            // Display initial view.
            DisplayView("View1");
        }

        private void SwitchViewEventHandler(string viewName)
        {
            DisplayView(viewName);
        }

        private void DisplayView(string viewName)
        {
            // Get a reference to the main region.
            IRegion mainRegion = _regionManager.Regions[RegionNames.MainRegion];

            // Create the view if we need to.
            object view = mainRegion.GetView(viewName);
            if (view == null)
            {
                switch (viewName)
                {
                    case "View1":
                        view = this._container.Resolve<View1>();
                        break;
                    case "View2":
                        view = this._container.Resolve<View2>();
                        break;
                }

                // Add the veiw to the main region.
                mainRegion.Add(view, viewName);
            }

            // Activate the view.
            if (view != null) mainRegion.Activate(view);
        }
    }
}
