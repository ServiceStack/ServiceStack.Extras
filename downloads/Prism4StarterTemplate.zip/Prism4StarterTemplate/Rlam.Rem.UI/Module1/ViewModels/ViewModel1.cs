﻿///////////////////////////////////////////////////////////////////////////////
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
///////////////////////////////////////////////////////////////////////////////
using System.Linq;
using System.ComponentModel;
using Common;
using Microsoft.Practices.Prism.Events;
using Module1.Models;
using Module1.Services;

namespace Module1.ViewModels
{
    /// <summary>
    /// Detail View 1. Uses loosely-coupled events to
    /// track the currently selected item in the Master view.
    /// </summary>
    public class ViewModel1 : INotifyPropertyChanged
    {
        private readonly IDataService _dataService;
        private readonly IEventAggregator _eventAggregator;

        public ViewModel1(IDataService dataService, IEventAggregator eventAggregator)
        {
            _dataService = dataService;
            _eventAggregator = eventAggregator;

            // Subscribe to the DataItemSelected event.
            _eventAggregator.GetEvent<DataItemSelectedEvent>().Subscribe(DataItemSelected, true);
        }

        private void DataItemSelected(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                CurrentItem = _dataService.GetModel().FirstOrDefault(item => item.Id == id);
                NotifyPropertyChanged("CurrentItem");
            }
        }

        public DataItem CurrentItem { get; set; }

        #region INotifyPropertyChanged Members
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion
    }
}
