﻿///////////////////////////////////////////////////////////////////////////////
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
///////////////////////////////////////////////////////////////////////////////
using System;
using System.ComponentModel;
using System.Windows.Data;
using Common;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Events;
using Module1.Models;
using Module1.Services;

namespace Module1.ViewModels
{
    /// <summary>
    /// ViewModel for the Master view. Illustrates common patterns
    /// for navigation and for selected item tracking.
    /// This example uses loosely-coupled events to communicate
    /// with the detail views and with other modules and components.
    /// </summary>
    public class MasterViewModel : INotifyPropertyChanged
    {
        private readonly IDataService _dataService;
        private readonly IEventAggregator _eventAggregator;
        private readonly DataItems _model;

        public MasterViewModel(IDataService dataService, IEventAggregator eventAggregator)
        {
            _dataService = dataService;
            _eventAggregator = eventAggregator;

            // Get the data model from the data service.
            _model = dataService.GetModel();

            // Initialize the CollectionView for the underlying model
            // and track the current selection.
            DataItemsCV = new ListCollectionView(_model);
            DataItemsCV.CurrentChanged += new EventHandler(SelectedItemChanged);

            // Initialize the SwitchView command.
            SwitchViewCommand = new DelegateCommand<string>(SwitchView);
        }

        #region DataItems CollectionView

        public ICollectionView DataItemsCV { get; private set; }

        private void SelectedItemChanged(object sender, EventArgs e)
        {
            DataItem item = DataItemsCV.CurrentItem as DataItem;
            if (item != null)
            {
                // Publish the DataItemSelected event.
                _eventAggregator.GetEvent<DataItemSelectedEvent>().Publish(item.Id);
            }
        }
        #endregion

        #region SwitchView Command
        public DelegateCommand<string> SwitchViewCommand { get; private set; }

        private void SwitchView(string viewName)
        {
            // Publish the switch view event through the event aggregator.
            _eventAggregator.GetEvent<SwitchViewEvent>().Publish(viewName);

            // Publish the DataItemSelected event.
            DataItem item = DataItemsCV.CurrentItem as DataItem;
            if (item != null)
            {
                _eventAggregator.GetEvent<DataItemSelectedEvent>().Publish(item.Id);
            }
        }

        #endregion

        #region INotifyPropertyChanged Members
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion
    }
}
