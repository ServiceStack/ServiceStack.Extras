﻿///////////////////////////////////////////////////////////////////////////////
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
///////////////////////////////////////////////////////////////////////////////
using Microsoft.Practices.Prism.Events;

namespace Module1
{
    /// <summary>
    /// An internal class that represent a loosely-coupled event
    /// to switch views into and out of the Shell's main region.
    /// </summary>
    public class SwitchViewEvent : CompositePresentationEvent<string>
    {
    }
}
