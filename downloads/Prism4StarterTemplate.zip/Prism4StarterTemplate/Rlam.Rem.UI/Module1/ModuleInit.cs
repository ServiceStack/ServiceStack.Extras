﻿///////////////////////////////////////////////////////////////////////////////
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
///////////////////////////////////////////////////////////////////////////////
using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Unity;

using Common;
using Module1.Views;
using Module1.Controllers;
using Module1.Services;

namespace Module1
{
    public class ModuleInit : IModule
    {
        private readonly IUnityContainer _container;
        private readonly IRegionManager _regionManager;
        private MainRegionController _mainRegionController;

        public ModuleInit(IUnityContainer container, IRegionManager regionManager)
        {
            _container = container;
            _regionManager = regionManager;
        }

        #region IModule Members

        public void Initialize()
        {
            // Register the DataService concrete type with the container.
            // Change this to swap in another data service implementation.
            _container.RegisterType<IDataService, DataService>();

            // Show the MasterView in the Shell's top left hand region.
            // This uses View Discovery to automatically shows the view in the region.
            _regionManager.RegisterViewWithRegion(RegionNames.TopLeftRegion, () => _container.Resolve<MasterView>());

            // Create the main region controller.
            // This is used to programmatically coordinate navigation and
            // the display of views in the main region.
            _mainRegionController = _container.Resolve<MainRegionController>();
        }

        #endregion
    }
}
