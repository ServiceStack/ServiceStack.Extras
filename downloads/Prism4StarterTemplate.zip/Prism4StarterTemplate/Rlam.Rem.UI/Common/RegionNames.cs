﻿///////////////////////////////////////////////////////////////////////////////
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
///////////////////////////////////////////////////////////////////////////////
using System;

namespace Common
{
    public static class RegionNames
    {
        public const string TopLeftRegion = "TopLeftRegion";
        public const string BottomLeftRegion = "BottomLeftRegion";
        public const string MainRegion = "MainRegion";
    }
}
