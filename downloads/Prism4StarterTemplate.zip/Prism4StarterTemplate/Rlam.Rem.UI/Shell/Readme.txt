Prism QuickStart Solution For WPF 4.0
-------------------------------------

This solution demonstrates a multi-module Prism WPF 4.0 application.

To compile and run this solution:

1. Download Prism (Version 2.2) from here (http://compositewpf.codeplex.com/releases/view/46046).
2. Compile the Prism assemblies for WPF 4.0.
3. Update the project references to point to the following Prism assemblies:

    - Microsoft.Practices.Composite.dll
    - Microsoft.Practices.Composite.Presentation.dll
    - Microsoft.Practices.Composite.UnityExtensions.dll
    - Microsoft.Practices.EnterpriseLibrary.Common.dll
    - Microsoft.Practices.EnterpriseLibrary.ExceptionHandling
    - Microsoft.Practices.EnterpriseLibrary.ExceptionHandling.Logging
    - Microsoft.Practices.EnterpriseLibrary.Logging
    - Microsoft.Practices.ServiceLocation.dll
    - Microsoft.Practices.Unity.dll
    - Microsoft.Practices.Unity.Configuration
    - Microsoft.Practices.Unity.Interception
    - Microsoft.Practices.Unity.Interception.Configuration

   An easy way to do this is to copy the above assemblies into a folder named 'Lib' under the solution folder.
