﻿///////////////////////////////////////////////////////////////////////////////
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
///////////////////////////////////////////////////////////////////////////////
using System;
using System.Windows;
using Microsoft.Practices.Prism.Logging;
using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Prism.UnityExtensions;
using Shell.Views;

namespace Shell
{
	public partial class Bootstrapper : UnityBootstrapper
	{
		private readonly EnterpriseLibraryLogger _logger = new EnterpriseLibraryLogger();

		protected override void ConfigureContainer()
		{
			base.ConfigureContainer();
		}

		protected override IModuleCatalog CreateModuleCatalog()
		{
			var catalog = new ModuleCatalog(new[]{
				new ModuleInfo("Module1", typeof(Module1.ModuleInit).AssemblyQualifiedName),              	
				new ModuleInfo("Module2", typeof(Module2.ModuleInit).AssemblyQualifiedName)
			});

			return catalog;
		}

		//protected override ILoggerFacade LoggerFacade
		//{
		//    get { return _logger; }
		//}

		protected override DependencyObject CreateShell()
		{
			// Use the container to create an instance of the shell.
			ShellView view = Container.TryResolve<ShellView>();

			// Display the shell's root visual.
			view.Show();

			return view;
		}
	}
}

